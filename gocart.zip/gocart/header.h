//======================================================
//  Libraries
//======================================================
  #include  <Relay.h>
  #include  <Button.h>
  #include  <HCSR04.h>
  #include  <TimeTrigger.h>
//======================================================
// 6 Buttons Set
//======================================================
  #define _button_lights_pin            33    // This Pin Is For Turnning On The Lights
  #define _button_reverse_pin           32    // This Pin Is For Changing Driving Direction
  #define _button_signal_left_pin       28    // This Pin Is For Signaling Left
  #define _button_shift_up_pin          30    // This Pin Is For Changing The Speed Up
  #define _button_signal_right_pin      31    // This Pin Is For Signaling Right
  #define _button_shift_down_pin        29    // This Pin Is For Changing The Speed Down
//======================================================
// 8 Relays / Set
//======================================================
  #define _power_pin                    10    // To Latch The Power
  #define _lights_pin                    9    // To Supply Power For Lights
  #define _signal_right_pin              8    // To Blink The Right Color
  #define _signal_left_pin               7    // To Blink The Left Color
  #define _speed_controller_pin              6    // To Turn On the Red Break Lights
  #define _reverse_lights_pin            5    // To Turn On the White Reverse Lights
  #define _throttle_pin                  4    // To Throttle Connect Or Disconnect
  #define _speed_shift_pin               3    // To Turn On the Speed Shift Up/Down
//======================================================
// Sensors Sections Pins And Objects
//======================================================
  // Break Sensor (Inductive Proximiy Switch)
  #define _sensor_break_pin             12    // This Is For The Sensor (Inductive Sensor)
  #define senBreakSetup                 pinMode(_sensor_break_pin, INPUT_PULLUP)
  #define senBreakRead                  digitalRead(_sensor_break_pin)
  // Buzzer
  #define _buzzer_pin                   A8    // This Is For The Sensor (Inductive Sensor)
  #define buzzerSetup                   pinMode(_buzzer_pin, OUTPUT)
  #define buzzerOn                      digitalWrite(_buzzer_pin, HIGH)
  #define buzzerOff                     digitalWrite(_buzzer_pin, LOW)
  // Ultrasonic Range Meter
  #define _sensor_ultrasound_trig       39    // This Is For The Sensor (Inductive Sensor)
  #define _sensor_ultrasound_echo       38    // This Is For The Sensor (Inductive Sensor)
  UltraSonicDistanceSensor              distanceSensor(_sensor_ultrasound_trig, _sensor_ultrasound_echo);
  #define senReadUS                     distanceSensor.measureDistanceCm()
//======================================================
// Timers
//======================================================
  TimeTrigger   blink(500);     // The Speed Of Blinking
  TimeTrigger   usReadInt(50);  // Reading Every 50mS
  TimeTrigger   powerOff(3000); // Hold 3 Button For 3 Seconds
//======================================================
// Button Objects
//======================================================
  Button  btnLights(_button_lights_pin);
  Button  btnReverse(_button_reverse_pin);
  Button  btnSignalLeft(_button_signal_left_pin);
  Button  btnSignalRight(_button_signal_right_pin);
  Button  btnShiftUp(_button_shift_up_pin);
  Button  btnShiftDown(_button_shift_down_pin);
//======================================================
// Relays Objects
//======================================================
  Relay   rlyPower(_power_pin, true);
  Relay   rlyThrottle(_throttle_pin, true);
  Relay   rlyLights(_lights_pin, true);
  Relay   rlySignalLeft(_signal_left_pin, true);
  Relay   rlySignalRight(_signal_right_pin, true);
  Relay   rlySpeedController(_speed_controller_pin, true);
  Relay   rlyReverse(_reverse_lights_pin, true);
  Relay   rlySpeed(_speed_shift_pin, true);
//======================================================
// Flags & Variables
//======================================================

  // Flags
  bool  _flag_breaks  = false;  // False = BKF, True = BKO
  bool  _flag_lights  = false;  // False = Off, True = On
  bool  _flag_right   = false;  // False = Off, True = On
  bool  _flag_left    = false;  // False = Off, True = On
  bool  _flag_dir     = false;  // False = BWD, True = FWD
  bool  _flag_speed   = false;  // False = MSP, True = HSP

  // Variables
  unsigned int distance = 0;
  
  // The Blink Trigger - Memory
  bool Signals = false;
  
//======================================================
// Rlay Beginning
//======================================================
  void beginRelays() {
    rlyPower.begin();
    rlyPower.turnOn();
    rlyThrottle.begin();
    rlyThrottle.turnOff();
    rlyLights.begin();
    rlyLights.turnOff();
    rlySignalLeft.begin();
    rlySignalLeft.turnOff();
    rlySignalRight.begin();
    rlySignalRight.turnOff();
    rlySpeedController.begin();
    rlySpeedController.turnOn();
    rlyReverse.begin();
    rlyReverse.turnOn();    // If On Means Moving Farward, If Off Moving Backwards
    rlySpeed.begin();
    rlySpeed.turnOff();
    _flag_dir = rlyReverse.getState();
  }
//======================================================
// Buttons Beginning
//======================================================
  void beginButtons() {
    btnLights.begin();
    btnReverse.begin();
    btnSignalLeft.begin();
    btnSignalRight.begin();
    btnShiftUp.begin();
    btnShiftDown.begin();
  }
//======================================================
// Sensors Beginning
//======================================================
  void beginSensors() {

    // Setup Buzzer
    buzzerSetup;
    buzzerOff;

    // Sensor Break
    senBreakSetup;
    senReadUS;

    // Beep 3 Time On Start
    for(int i=0; i<3; i++) {
      buzzerOn;
      delay(300);
      buzzerOff;
      delay(300);
    }
  }
